package com.eslam.du.lib000;

public class Joke {
    public static String tellAJoke() {

        return "what you called cant opener which cant open ??  \n cant opener hahahaha";
    }
}
